-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2026 at 02:19 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_usuario`
--

-- --------------------------------------------------------

--
-- Table structure for table `rol`
--

CREATE TABLE `rol` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rol`
--

INSERT INTO `rol` (`id`, `descripcion`) VALUES
(1, 'ADMINISTRADOR'),
(3, 'DONANTE'),
(4, 'VOLUNTARIO'),
(5, 'COORDINADOR DE DONACIONES'),
(6, 'COORDINADOR DE ADOPCIONES');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id` bigint(20) NOT NULL,
  `apmaterno` varchar(255) DEFAULT NULL,
  `appaterno` varchar(255) NOT NULL,
  `contrasena` varchar(60) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `direccion_id` bigint(20) NOT NULL,
  `dv` varchar(1) NOT NULL,
  `pnombre` varchar(255) NOT NULL,
  `rut` varchar(8) NOT NULL,
  `snombre` varchar(255) NOT NULL,
  `telefono` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `apmaterno`, `appaterno`, `contrasena`, `correo`, `direccion_id`, `dv`, `pnombre`, `rut`, `snombre`, `telefono`) VALUES
(1, 'Gomez', 'Perez', 'abc1234', 'juan@email.com', 1, '9', 'Juan', '12665678', 'Carlos', '123456789'),
(2, 'Llanten', 'Cerda', 'martina123', 'mart.cerdal@duocuc.com', 2, '3', 'Martina', '21930365', 'Isidora', '99995555'),
(3, 'Martínez', 'González', 'ivan123', 'ivaa.gonzalez@duocuc.cl', 3, 'k', 'Iván', '19903636', 'Antonio', '99996543'),
(4, 'Cañalao', 'Crépusculo', 'abscde21', 'cletus@gmail.com', 1, 'k', 'Cletus', '65584754', 'Caceres', '66779875'),
(5, 'Molina', 'Eusebio', 'EUSEVIOBRASIL', 'eusebio333@email.com', 2, '3', 'Romulo', '33384754', 'Fulgencio', '29559888');

-- --------------------------------------------------------

--
-- Table structure for table `usuario_rol`
--

CREATE TABLE `usuario_rol` (
  `id` bigint(20) NOT NULL,
  `rol_id` bigint(20) DEFAULT NULL,
  `usuario_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario_rol`
--

INSERT INTO `usuario_rol` (`id`, `rol_id`, `usuario_id`) VALUES
(1, 1, 1),
(2, 3, 1),
(3, 3, 2),
(4, 4, 3),
(5, 3, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario_rol`
--
ALTER TABLE `usuario_rol`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rol`
--
ALTER TABLE `rol`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `usuario_rol`
--
ALTER TABLE `usuario_rol`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
