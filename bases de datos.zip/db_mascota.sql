-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2026 at 02:19 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_mascota`
--

-- --------------------------------------------------------

--
-- Table structure for table `adopcion`
--

CREATE TABLE `adopcion` (
  `id` bigint(20) NOT NULL,
  `adoptante_id` bigint(20) NOT NULL,
  `fecha_adopcion` date NOT NULL,
  `mascota_id` bigint(20) NOT NULL,
  `voluntario_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adopcion`
--

INSERT INTO `adopcion` (`id`, `adoptante_id`, `fecha_adopcion`, `mascota_id`, `voluntario_id`) VALUES
(1, 3, '2026-05-16', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `mascota`
--

CREATE TABLE `mascota` (
  `id` bigint(20) NOT NULL,
  `coordinador_id` bigint(20) NOT NULL,
  `edad` int(11) NOT NULL,
  `especie` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `peso` double NOT NULL,
  `raza` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mascota`
--

INSERT INTO `mascota` (`id`, `coordinador_id`, `edad`, `especie`, `nombre`, `peso`, `raza`) VALUES
(1, 1, 3, 'Perro', 'Firulais', 14.5, 'Quiltro'),
(2, 1, 3, 'Perro', 'Snid', 21.5, 'Pastor Alemán'),
(3, 2, 8, 'Perro', 'Luna Cuccitini', 12, 'Quiltro'),
(4, 2, 4, 'Gato', 'Yoyo', 8.4, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adopcion`
--
ALTER TABLE `adopcion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adopcion`
--
ALTER TABLE `adopcion`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `mascota`
--
ALTER TABLE `mascota`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
