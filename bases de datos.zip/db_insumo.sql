-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2026 at 02:18 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_insumo`
--

-- --------------------------------------------------------

--
-- Table structure for table `donacion`
--

CREATE TABLE `donacion` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fechadonacion` date NOT NULL,
  `unidad` bigint(20) DEFAULT NULL,
  `usuario_id` bigint(20) DEFAULT NULL,
  `cantidad` bigint(20) NOT NULL,
  `insumo_id` bigint(20) DEFAULT NULL,
  `campana_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donacion`
--

INSERT INTO `donacion` (`id`, `descripcion`, `fechadonacion`, `unidad`, `usuario_id`, `cantidad`, `insumo_id`, `campana_id`) VALUES
(11, 'Donación de mascarillas', '2026-05-16', NULL, 2, 100, 3, NULL),
(12, 'Donacion de chalecos para perro mediano', '2026-06-17', NULL, 1, 10, 4, 1),
(13, 'Desparasitantes perro', '2026-07-16', NULL, 1, 10, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `insumo`
--

CREATE TABLE `insumo` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `unidad` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insumo`
--

INSERT INTO `insumo` (`id`, `descripcion`, `unidad`) VALUES
(1, 'Alimento', 'Kilogramos'),
(2, 'Medicina/mg', 'Miligramos'),
(3, 'Medicina/ml', 'Mililitros'),
(4, 'Juguete', ''),
(5, 'Ropa', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donacion`
--
ALTER TABLE `donacion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insumo`
--
ALTER TABLE `insumo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donacion`
--
ALTER TABLE `donacion`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `insumo`
--
ALTER TABLE `insumo`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
