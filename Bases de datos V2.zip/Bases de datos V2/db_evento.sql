-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2026 at 06:09 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_evento`
--

-- --------------------------------------------------------

--
-- Table structure for table `campania`
--

CREATE TABLE `campania` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fecha_fin` date NOT NULL,
  `fecha_ini` date NOT NULL,
  `id_administrador` bigint(20) NOT NULL,
  `id_coordinador1` bigint(20) NOT NULL,
  `id_coordinador2` bigint(20) DEFAULT NULL,
  `id_coordinador3` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `campania`
--

INSERT INTO `campania` (`id`, `descripcion`, `fecha_fin`, `fecha_ini`, `id_administrador`, `id_coordinador1`, `id_coordinador2`, `id_coordinador3`) VALUES
(1, 'Campaña de invierno 2026', '2026-06-30', '2026-06-02', 3, 2, NULL, NULL),
(2, 'Campaña de verano 25-26', '2026-04-30', '2025-12-20', 1, 2, NULL, NULL),
(3, 'Campaña terremoto 2027', '2027-04-30', '2027-03-10', 4, 3, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `campania`
--
ALTER TABLE `campania`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `campania`
--
ALTER TABLE `campania`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
