-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2026 at 06:09 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_insumo`
--

-- --------------------------------------------------------

--
-- Table structure for table `donacion`
--

CREATE TABLE `donacion` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `fechadonacion` date NOT NULL,
  `unidad` bigint(20) DEFAULT NULL,
  `usuario_id` bigint(20) DEFAULT NULL,
  `cantidad` bigint(20) NOT NULL,
  `insumo_id` bigint(20) DEFAULT NULL,
  `campana_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donacion`
--

INSERT INTO `donacion` (`id`, `descripcion`, `fechadonacion`, `unidad`, `usuario_id`, `cantidad`, `insumo_id`, `campana_id`) VALUES
(17, 'sacos comida doge', '2026-06-15', NULL, 1, 21, 1, NULL),
(19, '500 mg de medicina ASESINA DE GARRAPATAS 666', '2026-06-16', NULL, 11, 500, 2, NULL),
(20, 'juguetes masticable perro        p', '2026-06-16', NULL, 12, 3, 4, NULL),
(21, '12 kilos de comida marca cachupin', '2026-06-16', NULL, 14, 12, 1, NULL),
(22, 'frasco 60 miligramos erradicador de pulgas 666', '2026-06-16', NULL, 15, 60, 2, NULL),
(23, 'sacos de comida marca doge', '2026-06-18', NULL, 16, 10, 1, NULL),
(25, 'poleron perro grande y gordo', '2026-06-18', NULL, 17, 2, 5, NULL),
(26, 'donacion doge', '2026-06-20', NULL, 20, 2, 4, NULL),
(27, 'donacion test', '2026-07-20', NULL, 20, 22, 4, NULL),
(28, 'donacion test2', '2026-07-21', NULL, 20, 32, 4, NULL),
(29, 'donacion test4', '2026-07-21', NULL, 20, 46, 4, NULL),
(30, 'donacion test5', '2026-07-21', NULL, 20, 48, 4, NULL),
(31, 'AAA', '2026-07-01', NULL, 2, 56, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `insumo`
--

CREATE TABLE `insumo` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `unidad` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insumo`
--

INSERT INTO `insumo` (`id`, `descripcion`, `unidad`) VALUES
(1, 'Alimento(Kilogramos)', 'Kilogramos'),
(2, 'Medicina/mg', 'Miligramos'),
(3, 'Medicina/ml', 'Mililitros'),
(4, 'Juguete', ''),
(5, 'Ropa', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donacion`
--
ALTER TABLE `donacion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insumo`
--
ALTER TABLE `insumo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donacion`
--
ALTER TABLE `donacion`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `insumo`
--
ALTER TABLE `insumo`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
