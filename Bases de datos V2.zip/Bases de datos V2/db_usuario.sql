-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2026 at 06:10 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_usuario`
--

-- --------------------------------------------------------

--
-- Table structure for table `rol`
--

CREATE TABLE `rol` (
  `id` bigint(20) NOT NULL,
  `descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rol`
--

INSERT INTO `rol` (`id`, `descripcion`) VALUES
(1, 'ADMINISTRADOR'),
(3, 'USUARIOREG'),
(4, 'INVITADO'),
(5, 'COORDINADOR DE DONACIONES'),
(6, 'COORDINADOR DE ADOPCIONES');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `id` bigint(20) NOT NULL,
  `apmaterno` varchar(255) DEFAULT NULL,
  `appaterno` varchar(255) NOT NULL,
  `contrasena` varchar(255) DEFAULT NULL,
  `correo` varchar(255) NOT NULL,
  `direccion_id` bigint(20) NOT NULL,
  `dv` varchar(1) NOT NULL,
  `pnombre` varchar(255) NOT NULL,
  `rut` varchar(8) NOT NULL,
  `snombre` varchar(255) DEFAULT NULL,
  `telefono` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `apmaterno`, `appaterno`, `contrasena`, `correo`, `direccion_id`, `dv`, `pnombre`, `rut`, `snombre`, `telefono`) VALUES
(2, 'Llanten', 'Cerda', 'martina123', 'mart.cerdal@duocuc.com', 2, '3', 'Martina', '21930365', 'Isidora', '99995555'),
(4, 'Cañalao', 'Crépusculo', 'abscde21', 'cletus@gmail.com', 1, 'k', 'Cletus', '65584754', 'Caceres', '66779875'),
(5, 'Molina', 'Eusebio', 'EUSEVIOBRASIL', 'eusebio333@email.com', 2, '3', 'Romulo', '33384754', 'Fulgencio', '29559888'),
(6, 'Cañalao', 'Crépusculo', 'abscde21', 'cletu2s@email.com', 1, 'k', 'Cle2tus', '66684754', 'Caceeres', '66722875'),
(11, 'Cañalao', 'Correa', NULL, 'SATANAS@INFIERNO.COM', 1, '4', 'Crepusculo', '12344476', NULL, '56966666666'),
(13, 'Romulo', 'Cardenas', 'contraseña12345', 'AYUDA@GMAIL.COM', 1, '4', 'Doge', '12345888', 'Homosexual', '56977773333'),
(14, 'Puto', 'Validivia', NULL, 'luis@email.com', 1, '4', 'Jorge', '12222222', '', '+56911116666'),
(15, 'Mora', 'Sanchez', NULL, 'rick@gmail.com', 1, '1', 'Pepinillo', '1111111', 'Rick', '56922224444'),
(16, 'Tercero', 'Romulo', NULL, 'doge@hotmail.com', 1, 'K', 'Pedro', '12345666', 'Jorge', '56976544432'),
(17, 'Crepusculo', 'Molina', NULL, 'abi@cresencio.com', 1, 'K', 'Diego', '16777222', 'Carlos', '56966633377'),
(18, 'Caceres', 'Lazcano', 'cristian123', 'pedro@jorge.aol', 1, '0', 'Cristiano', '13333333', 'Ronaldo', '56911112222'),
(20, 'Carreras', 'Romero', NULL, 'crisnuevomail@email.com', 4, 'k', 'Cristiano', '19999999', 'Francisco', '+56911777777'),
(21, 'Molina', 'Barvatov', NULL, 'aaaasssss@email.com', 4, '0', 'Rolando', '12000000', 'Morrigan', '+56922334455'),
(22, 'Fuentes', 'Grimaldo', 'string', 'grimm@gmail.com', 1, '7', 'Fabián', '12346667', 'Alberto', '+56934422345'),
(23, 'test1', 'test1', NULL, 'test@email.com', 4, '1', 'test1', '12345643', 'test1', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `usuario_rol`
--

CREATE TABLE `usuario_rol` (
  `id` bigint(20) NOT NULL,
  `rol_id` bigint(20) DEFAULT NULL,
  `usuario_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario_rol`
--

INSERT INTO `usuario_rol` (`id`, `rol_id`, `usuario_id`) VALUES
(1, 1, 1),
(2, 3, 1),
(3, 3, 2),
(4, 4, 3),
(5, 3, 3),
(6, 4, 12),
(7, 3, 13),
(8, 4, 14),
(9, 4, 15),
(10, 4, 16),
(11, 4, 17),
(12, 3, 18),
(13, 5, 4),
(14, 4, 19),
(15, 4, 20),
(16, 4, 21),
(17, 3, 22),
(18, 4, 23);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario_rol`
--
ALTER TABLE `usuario_rol`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rol`
--
ALTER TABLE `rol`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `usuario_rol`
--
ALTER TABLE `usuario_rol`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
